import React, { Component } from 'react'
import CrudForm from './crudForm'
import { connect } from "react-redux";
import * as action from "../action/crudTask"
import { bindActionCreators } from "redux";

class crudTable extends Component {
    handleEdit = (index) => {
        this.props.updateCrudIndex(index)
    }

    handleDelete = (index) => {
        this.props.deleteCrud(index)
    }

    render() {
        return (
            <div>
                <CrudForm />
                <hr />
                <table  
                    border="1"
                    cellPadding="10px"
                    cellSpacing="0px"
                    width="auto"
                >
                    <tbody>
                    <tr>
                        <th width="10px">No</th>
                        <th>Phone No.</th>
                        <th>KTP No.</th>
                        <th>KK No.</th>
                        <th>Full Name</th>
                        <th colSpan='2'>Aksi</th>
                    </tr>
                        {this.props.list.map((item, index) => {
                            return <tr key={index}>
                                <td width="10px">{index + 1}</td>
                                <td>{item.phoneNo}</td>
                                <td>{item.KTP}</td>
                                <td>{item.KK}</td>
                                <td>{item.fullName}</td>
                                <td><button onClick={() => this.handleEdit(index)}>Edit</button></td>
                                <td><button onClick={() => this.handleDelete(index)}>Delete</button></td>
                            </tr>
                        })}
                    </tbody>
                </table>
            </div>
        )
    }
}

const mapStateToProps = (state) => {
    return {
        list: state.list
    }
}

const mapDispatchToProps = (dispatch) => {
    return bindActionCreators({
        updateCrudIndex: action.updateIndex,
        deleteCrud: action.Delete
    }, dispatch)
}

export default connect(mapStateToProps, mapDispatchToProps)(crudTable)