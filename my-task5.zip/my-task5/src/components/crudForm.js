import React, { Component } from 'react'
import { connect } from 'react-redux'
import * as action from "../action/crudTask"
import { bindActionCreators } from "redux"

class crudForm extends Component {

    state = {
        ...this.returnStateObject()
    }

    returnStateObject() {
        if (this.props.currentIndex === -1)
            return {
                phoneNo: '',
                KTP: '',
                KK: '',
                fullName: ''
            }
        else
            return this.props.list[this.props.currentIndex]
    }

    componentDidUpdate(prevProps) {
        if (prevProps.currentIndex !== this.props.currentIndex || prevProps.list.length !== this.props.list.length) {
            this.setState({ ...this.returnStateObject() })
        }
    }

    handleInputChange = (e) => {
        this.setState({
            [e.target.name]: e.target.value
        })
    }

    handleSubmit = (e) => {
        e.preventDefault()
        if (this.props.currentIndex === -1)
            this.props.insertCrud(this.state)
        else
            this.props.updateCrud(this.state)
    }

    render() {
        const formstyle = {
            width: "100%",
            color: "white",
            backgroundColor: "#4a023f",
            fontFamily: "Arial"
        };
        const btnstyle = {
            width: "30%",
            color: "white",
            backgroundColor: "black",
            fontFamily: "Arial"
        }
        return (
            <>
                <h2>
                    Cellular Card Registration
                </h2>
                <form onSubmit={this.handleSubmit} >
                    < input name="phoneNo" placeholder="Phone Number" onChange={this.handleInputChange} value={this.state.phoneNo} style={formstyle}/><br />
                    < input name="KTP" placeholder="KTP Number" onChange={this.handleInputChange} value={this.state.KTP} style={formstyle}/><br />
                    < input name="KK" placeholder="KK Number" onChange={this.handleInputChange} value={this.state.KK} style={formstyle}/><br />
                    < input name="fullName" placeholder="Full Name" onChange={this.handleInputChange} value={this.state.fullName} style={formstyle}/><br />
                    <button type="submit" style={btnstyle}>Submit</button>
                </form>
            </>
        )
    }
}

const mapStateToProps = state => {
    return {
        list: state.list,
        currentIndex: state.currentIndex
    }
}

const mapDispatchToProps = dispatch => {
    return bindActionCreators({
        insertCrud: action.insert,
        updateCrud: action.update
    }, dispatch)
}

export default connect(mapStateToProps, mapDispatchToProps)(crudForm)