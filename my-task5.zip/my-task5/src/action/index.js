import { insert, update, Delete, updateIndex } from './crudTask'

export { insert, update, Delete, updateIndex }