export const INSERT = 'INSERT'
export const UPDATE = 'UPDATE'
export const DELETE = 'DELETE'
export const UPDATE_INDEX = 'UPDATE_INDEX'