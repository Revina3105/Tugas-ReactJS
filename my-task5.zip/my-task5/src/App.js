import React from 'react';
import './App.css';
import CrudTable from './components/crudTable';

function App() {
  return (
    <CrudTable />
  );
}

export default App;
